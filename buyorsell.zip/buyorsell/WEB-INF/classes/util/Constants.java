package util;

public class Constants {

	public static final String MongoDatabaseName = "BuyOrSell";
	public static final String MongoCollectionName = "Reviews";
	
	//Pavithra: Need to differentiate seller review from product review;
	public static final String MongoSellerReviewCollectionName = "Seller Reviews";
}

