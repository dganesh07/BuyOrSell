-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: ewa_project
-- ------------------------------------------------------
-- Server version	5.7.16-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `advertisement`
--

DROP TABLE IF EXISTS `advertisement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `advertisement` (
  `id` int(11) NOT NULL,
  `title` varchar(150) DEFAULT NULL,
  `description` varchar(1000) DEFAULT NULL,
  `itemCondition` varchar(5) DEFAULT NULL,
  `categoryId` int(11) DEFAULT NULL,
  `imageName` varchar(300) DEFAULT NULL,
  `isNegotiable` tinyint(1) DEFAULT NULL,
  `price` float DEFAULT NULL,
  `addressId` int(11) DEFAULT NULL,
  `contactNumber` varchar(10) DEFAULT NULL,
  `displayContactNumber` tinyint(1) DEFAULT '0',
  `postedBy` int(11) DEFAULT NULL,
  `postedDate` date DEFAULT NULL,
  `isActive` tinyint(4) DEFAULT '1',
  `isFeatured` tinyint(4) DEFAULT '0',
  `isSoldOut` tinyint(4) DEFAULT '0',
  `viewCount` int(11) DEFAULT '0',
  `updatedDate` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `categoryId` (`categoryId`),
  KEY `addressId` (`addressId`),
  KEY `postedBy` (`postedBy`),
  CONSTRAINT `advertisement_ibfk_2` FOREIGN KEY (`addressId`) REFERENCES `address` (`id`),
  CONSTRAINT `advertisement_ibfk_3` FOREIGN KEY (`postedBy`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `advertisement`
--

LOCK TABLES `advertisement` WRITE;
/*!40000 ALTER TABLE `advertisement` DISABLE KEYS */;
INSERT INTO `advertisement` VALUES (29723861,'Hot Wheels 20-Car Gift Pack (Styles May Vary)','It\'s a toy for kids. Age Range: 3Y+, Packs include nine Hot Wheels vehicles with genuine die-cast parts, Kids can collect their favorites and trade with friends.','NEW',31,'',1,20,503598146,'5678767898',1,741810915,'2016-12-02',1,0,0,0,'2016-12-02'),(117306050,'Electric Rice Cooker','10-cup Electric Rice Cooker, automatically switches from cook to warm','NEW',31,'',1,67.98,1,'6758978675',1,2,'2016-12-02',1,0,0,0,'2016-12-02'),(141482616,'New Java Book','Great book. Offers lot of coding questions for interview preparation. Just got a job at Microsoft using this book.','NEW',28,'',1,20,366525612,'1234567890',1,519285415,'2016-12-02',1,0,0,0,'2016-12-02'),(147327523,'Used iPhone 6s for sale','White iPhone 6s with slight wear and tears is for sale. Seldom used as I am not a phone person, contact me if you want more pictures or any other details.','OLD',2,'',1,300,503598146,'5678987654',1,741810915,'2016-12-02',1,0,0,0,'2016-12-02'),(156009887,'The Godfather','Preowned book with slight wear and tear for sale','OLD',28,'',1,2,2,'7865678908',1,4,'2016-12-02',1,0,0,0,'2016-12-02'),(185715091,'Ikevan Women Bohemian Bracelet Woven Braided Handmade Wrap Cuff Magnetic Clasp','100% brand new and high quality , Material: PU Leather,Rhinestone , Size: 40*2cm , Color: Gold,Pink,Blue,Gray,Black.','NEW',23,'',1,3,3,'3125678678',1,1,'2016-12-02',1,0,0,0,'2016-12-02'),(313138148,'Furniture - Study desk','Study table desk furniture, suitable for both laptop and desktop computers','NEW',11,'',1,34.89,3,'3125678456',1,1,'2016-12-02',1,0,0,0,'2016-12-02'),(332553756,'Used iPhone case and data cable for','Fits iPhone 5s, clor:Blue, it looks like new.','OLD',31,'',1,3,2,'6789765456',1,4,'2016-12-02',1,0,0,0,'2016-12-02'),(338385750,'T-fal Basic Non-Stick Easy Care 10\" Fry Pan','Superior nonstick interior and exterior, Base delivers even heat distribution, Dishwasher-safe.','NEW',31,'',1,24.78,1,'5678976859',1,2,'2016-12-02',1,0,0,0,'2016-12-02'),(455771700,'ipadAir for Sale','Comes with original package. 1 year Apple warranty, comes with accessories. Color: grey','NEW',4,'',1,600,1634930298,'786789876',1,1430068372,'2016-12-02',1,0,0,0,'2016-12-02'),(474644031,'Bike for sale','1 year old bike runs just fine. Reason for selling is I am getting a new one.','OLD',31,'',1,30,1603884112,'8687564567',1,3,'2016-12-02',1,0,0,0,'2016-12-02'),(532236578,'Handbag for sale!!','New blue handbag for sale, reasonable price, color-Blue. Strictly no returns or exchange. Contact me for more details.','NEW',14,'',1,45.99,3,'3128967548',1,1,'2016-12-02',1,0,0,0,'2016-12-02'),(559249460,'Used laptop monitor','Seldom used LCD monitor, comes with mouse as a compliment. It works perfectly fine, feeling it because of relocation.','OLD',8,'',1,70,1603884112,'7689087654',1,3,'2016-12-02',1,0,0,0,'2016-12-02'),(615357550,'Audix OM5 Dynamic Microphone, Hyper-Cardioid','High-quality sound at very high SPLs without distorion or feedback. Naturally attenuated at 120Hz to reduce boominess and handling noise. Mid-range tailored for clarity and presence VLM (Very Low Mass) technology delivers outstanding transient response.','NEW',19,'',1,99.99,2,'5678987654',1,4,'2016-12-02',1,0,0,0,'2016-12-02'),(687679562,'Preowned book for free','I have a book which I finished reading and would like to share it with people who are interested.','OLD',28,'',1,0,1,'5467897689',1,2,'2016-12-02',1,0,0,0,'2016-12-02'),(788838632,'MICHAEL Michael Kors Jet Set Top-Zip Tote','This chic East West tote from Michael Kors is wrapped in saffiano finished leather with polished hardware. The interior is lined in Kors logo fabric and features a zippered pocket, four open slip pockets, and a key fob. It has a fully zippered top closure, and there are side gusset pockets for additional storage.','NEW',14,'',1,267.99,1,'8474578965',1,2,'2016-12-02',1,0,0,0,'2016-12-02'),(804907393,'ipadMini4 - Best deal you could ask for!!','Comes with original package, includes accessories such as charger, ear phones, apple logo. Color: Silver.','NEW',4,'',1,380,1634930298,'678765434',1,1430068372,'2016-12-02',1,0,0,0,'2016-12-02'),(840848748,'Columbia jacket - Used','Used Columbia jacket with few stains near the collar is up for sale. I would really appreciate if you could take it today itself, inbox me for more details.It is negotiable.','OLD',23,'',1,40,503598146,'7869809876',1,741810915,'2016-12-02',1,0,0,0,'2016-12-02'),(1028413693,'Samsung Galaxy Note 7','Phone is in excellent condition, reason to sell is I am switching to IOS. It has to go by this weekend','OLD',2,'',1,399.99,1603884112,'7685645678',1,3,'2016-12-02',1,0,0,0,'2016-12-02'),(1128086522,'Secret Treasure\'s Women\'s and Women\'s Plus Hooded Character Sleepwear Adult Onesie Costume Union Suit Pajama (Sizes XS-3X)','100% polyester, One-piece pajama suit,Micro fleece construction','NEW',22,'',1,10.99,1603884112,'7865678976',1,3,'2016-12-02',1,0,0,0,'2016-12-02'),(1133801999,'Used iPad mini 2 for sale','Color: white, Capacity: 32gb. It looks like new, comes with a beautiful case.','OLD',4,'',1,100,503598146,'7867898767',1,741810915,'2016-12-02',1,0,0,0,'2016-12-02'),(1174527429,'Google Nexus phone','This is an old phone of mine. It has some awesome features, best suited for people  who are not tech savvy.','OLD',2,'',1,100,1634930298,'6756789876',1,1430068372,'2016-12-02',1,0,0,0,'2016-12-02'),(1183691102,'Panasonic LUMIX DMC-FZ70 16.1 MP Digital Camera with 60x Optical Image Stabilized Zoom and 3-Inch LCD (Black)','Bring the action in super close with category class leading 60X optical zoom (20mm-1200mm) Experience Full 1080/60i HD Panasonic Video recording with auto focus Zoom focused Dolby quality sound recording locks out ambient noise for enhanced audio quality. Contact me for a good deal','NEW',5,'',1,899.99,2,'7867898789',1,4,'2016-12-02',1,0,0,0,'2016-12-02'),(1258801442,'Kate Spade handbag for sale','Color: red, type: sling, new condition.','NEW',14,'',1,400,1,'5674568790',1,2,'2016-12-02',1,0,0,0,'2016-12-02'),(1303075444,'Sofa and loveseat for sale','Brand new items, door delivery is available with minimal charge.','NEW',9,'',1,150.78,3,'3127657689',1,1,'2016-12-02',1,0,0,0,'2016-12-02'),(1404350923,'Womens Black Velvet Choker Necklace for Girls Lace Choker Tattoo Necklace','Product Dimensions: 6.6 x 4.8 x 1.2 inches, item model number: N0199800H55-NWUS','NEW',31,'',1,5,2,'6789876543',1,4,'2016-12-02',1,0,0,0,'2016-12-02'),(1510306092,'Nike Kids Roshe One (PS) Running Shoe','Padded tongue with NIKE swoosh logo, Lace up closure.','NEW',31,'',1,20.88,1603884112,'6578976789',1,3,'2016-12-02',1,0,0,0,'2016-12-02'),(1554241959,'Sony MDRZX100 ZX Series Stereo Headphones (Blue) With Oroview Pop Filter Studio Mic Wind Screen Pop Filter - For Sale','Sony MDRZX100 ZX Series Stereo Headphones (Blue) With Oroview Pop Filter Studio Mic Wind Screen Pop Filter, manufacturer_part_number - MDRZX100','NEW',6,'',1,99,503598146,'7689876543',1,741810915,'2016-12-02',1,0,0,0,'2016-12-02'),(1565439481,'Faded Glory Women\'s Zipper Boot','The Faded Glory Women\'s Zipper Boot is a comfy and versatile piece of footwear that works all year round. The upper is made of durable PU with a classic faux leather construction and features a chic set of zippers on each side that not only keeps the shoes manageable, but also provides a layered look.','NEW',23,'',1,56.99,1,'',1,2,'2016-12-02',1,0,0,0,'2016-12-02'),(1568615220,'Mac lipstick - Cherry red','Brand new cherry red mac lipstick, comes with original packing. Matte finish and long lasting.','NEW',25,'',1,17.99,2,'4567894321',1,4,'2016-12-02',1,0,0,0,'2016-12-02'),(1637013334,'Beats by Dr. Dre urBeats In-Ear Earbud Headphones','Beats by Dr. Dre Powerbeats2 Wireless In Ear Headphones. Easily pairs to your Bluetooth device with 30\' range, Premium sound performance and rechargeable 6-hour battery, Sweat- and water-resistant','NEW',6,'',1,67.99,3,'3126754378',1,1,'2016-12-02',1,0,0,0,'2016-12-02'),(1800877028,'Stack of books, must go today','I am relocating to accommodate my job and cannot carry everything I have. I know there are many people who would like to read books in free time, please feel free to collect it from my place. Must go today','OLD',28,'',1,0,2,'8768980897',1,4,'2016-12-02',1,0,0,0,'2016-12-02'),(1889033387,'Used Laptop for sale','2 years old laptop, silver color. Works perfectly fine, contact me for more details about configuration, price negotiation etc..','OLD',3,'',1,200,2,'5675456789',1,4,'2016-12-02',1,0,0,0,'2016-12-02'),(1897877615,'Lenovo Laptop ','Brand new Lenovo laptop, black. 2 years Manufacturer warranty. Box is intact.','NEW',3,'',1,900,1634930298,'7867876545',1,1430068372,'2016-12-02',1,0,0,0,'2016-12-02'),(1927381945,'Maestro by Gibson MA41BKCH 41\" Full Size Acoustic Guitar Kit','The Maestro by Gibson 41\" full-size guitar packs offer outstanding playability. Built by Gibson Innovations, a division of world-famous Gibson Guitars, the Maestro full size guitar delivers a big, clear sound at an extremely moderate price.','OLD',18,'',1,1000.99,503598146,'8797654567',1,741810915,'2016-12-02',1,0,0,0,'2016-12-02'),(1936994405,'Mac lipstick - Pinky lips','Brand new pink mac lipstick, comes with original packing. Matte finish and long lasting.','NEW',25,'',1,17.99,2,'7657898765',1,4,'2016-12-02',1,0,0,0,'2016-12-02'),(2126587885,'Fashion Diva country side style neckpiece','This makes you look stylish and goes with any modern attire.','NEW',31,'',1,12,1603884112,'6789876543',1,3,'2016-12-02',1,0,0,0,'2016-12-02');
/*!40000 ALTER TABLE `advertisement` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-12-03  0:02:47
